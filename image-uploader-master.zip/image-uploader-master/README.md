# Image Uploader - OpenShift in Action

This is the application used in Chapter 2 of OpenShift in Action as an example of building and deploying your first OpenShift applicaitons.
