<?php echo "My IP: : {$_SERVER['SERVER_ADDR']} at " , date("D M j G:i:s T Y"); ?>
